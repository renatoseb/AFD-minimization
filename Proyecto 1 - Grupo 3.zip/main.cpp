#include "automata.h"

    // Autores: 
    //     - Barrueta Aspajo, Frings Douglas
    //     - Riveros Soto, Andres
    //     - Rodríguez Llanos, Renato Sebastian

    // GitHub: 
    //     - https://github.com/renatoseb/AFD-minimization.git
int main(){

    Automata a;
    Automata b;
    std::cin >> a;
    b = a.brzozowski();
    std::cout << b;
    return 0;
}
